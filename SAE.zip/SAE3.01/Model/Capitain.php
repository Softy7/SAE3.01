<?php
include_once('Team.php');
include_once('Player.php');

/**
 *
 */
class Capitain extends Player {
    /**
     * @var Team
     */
    public Team $team;

    /**
     * @param $un "le pseudo du capitain
     * @param $m "le mail du capitain
     * @param $n "le nom du capitain
     * @param $fn "le pénom du capitain
     * @param $b "la date de naissace du capitain écrit sous la forme jj/mm/aaaa
     * @param $p "le mot de passe du capitain
     * @param $tn "le nom de l'équipe que le capitaine souhaite créé
     * @param array $pl liste des joueurs qui veulent être dans l'équipe
     */
    function __construct($un, $m, $n, $fn, $b, $p, $tn, array $pl)
    {
        parent::__construct($un, $m, $n, $fn, $b, $p);
        $bdd = new PDO ("pgsql:host=localhost;dbname=postgres", 'postgres', 'v1c70I83');
        $scearchTeamName=$this->scearchName($tn, $bdd);//cherche si le nom de l'équipe existe déjà ou non.
        if($scearchTeamName/*est un booléen*/) {//si il est trouvé dans la base de donné
            return false;//à utiliser avec un affichage pour envoyer un message d'erreur
        } else {
            $this->team = new Team($tn);
            foreach ($pl as $player) {
                $this->team->addPlayer($player);
                $request=$bdd->prepare("UPDATE Guests SET Team=:teamName WHERE username=:playerUsername");
                $request->bindParam(':teamName',$this->team->name);
                $request->bindParam(':playerUsername',$player->getUsername);
                $request->execute();
            }
            $this->team->setCapitain($this);
            $request = $bdd->prepare(" insert into Capitain VALUES (:username,:teamName) ");
            $request->bindParam(':username', $un);
            $request->bindParam(':teamName', $tn);
            $request->execute();
            return true;//à utiliser avec un affichage pour envoyer un message pour dire que la team a bien été créé
        }



    }

    function updateTeam($player){//à modifier
        for ($i=0;$player==$this->team->listPlayer[$i];$i++){
            if ($player==$this->team->listPlayer[$i]){
                $this->team->removePlayer($player);
            }
        }
        $this->team->addPlayer($player);

        /* si 1 cap et un joueur et qu on veux suprimmer un joueur alors dissoudre l equipe
         * si 4 joueur bloquer l ajout de joueur
         * dois pouvoir voir la liste de joueur
         * condition si joueur choisi
         *     retirer joueur
         * sinon
         *     ajouter joueur
         */
    }

    public function deleteTeam(){//dissoudre
            $bdd = new PDO ("pgsql:host=localhost;dbname=postgres", 'postgres', 'v1c70I83');

            $request = $bdd->prepare("Delete 
                                        from capitain
                                        WHERE username = :username ");//retire se joueur son equipe
            $request->bindValue(':username', $this->username, PDO::PARAM_STR);
            $teamname = $request->execute();
            $request2 = $bdd->prepare("Delete
                                        From Team
                                        where teamname = :teamname ");
            $request2->bindParam(':teamname', $teamname);
            $request2->execute();
            $requete = $bdd->prepare("UPDATE Guests SET Team=null WHERE username=:capUsername");
            $requete->bindParam(':capUsername', $this->username);
            $requete->execute();
            new Player($this->username, $this->getMail(), $this->getName(), $this->getFirstname(), $this->getBirthday(), $this->getPassword());

    }

    function searchPlayer($search/*recherche nom,prénom ou username,*/): array{
        $players = array();
        $bdd = new PDO ("pgsql:host=localhost;dbname=postgres",'postgres','v1c70I83');
        $lines = array("username", "name", "firstname");
        for ($i=0; $i<3; $i++) {
            $SUN = $bdd->prepare("SELECT username, name, firstname, team 
                                        FROM Guests 
                                        WHERE :lines = :search");//recherche dans la base de donné
            $SUN->bindParam(':lines',$lines[i]);
            $SUN->bindParam(':search',$search);
            $SUN->execute();
            $SUN = $SUN->fetchAll();
            foreach ($SUN as $row) {
                $attributes = array();
                $attributes[0] = $row['username']; // Accède à la colonne 'username'
                $attributes[1] = $row['name'];    // Accède à la colonne 'name'
                $attributes[2] = $row['firstname']; // Accède à la colonne 'firstname'
                $attributes[3] = $row['team'];  // accède à la colonne 'Team'
                $players[-1] = $attributes;
            }
        }
        return $players;
    }

    function addPlayer($seachPlayer){
        $this->team->addPlayer($seachPlayer);
    }

    function bet($match){
        if($match->getTeam1=$this){
            $match->setBetT1($this);
        }
        else{
            $match->setBetT2($this);
        }
    }

    /**
     * @param Player $playerSelected joueur que le capitain souhaite passer capitain
     * @return void
     */
    function chooseNewCapitain($playerSelected){
        $bdd = new PDO ("pgsql:host=localhost;dbname=postgres",'postgres','v1c70I83');
        $request = $bdd->prepare("update capitain set username = :playerSelectedUsername WHERE teamname = :teamName");
        $request->bindValue(':playerSelectedUsername',$playerSelected->username);
        $request->bindValue(':teamName',$this->team->name);
        $request->execute();
        /*
        $request = $bdd->prepare("DELETE FROM capitain WHERE username = :ancienCapUsername");
        $request->bindValue(':ancienCapUsername',$this->username);
        $request->execute();

        $request = $bdd->prepare("INSERT INTO Capitain VALUES(:playerSelectedUsername,:teamName);
        $request->bindValue(':playerSelectedUsername',$playerSelected->username);
        $request->bindValue(':teamName',$this->team->name);
        $requete->execute();

        si le code ci-dessus ne marche pas.
        */
        $requete = $bdd->prepare("UPDATE Guests SET Team=null WHERE username=:ancienCapUsername");
        $requete->bindValue(':ancienCapUsername',$this->username);
        $requete->execute();

    }
}
