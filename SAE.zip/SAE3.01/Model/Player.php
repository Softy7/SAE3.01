<?php
require_once('Team.php');
require_once('Member.php');

class Player extends Member {
    private $team;

    function __construct($un, $m, $n, $fn, $b, $p, $t) {
        parent::__construct($un, $m, $n, $fn, $b, $p);
        $this->team = $t;
    }

    public function getUsername()
    {
        return $this->username;
    }

    public function setTeam($team) {
        $bdd = new PDO ("pgsql:host=localhost;dbname=postgres",'postgres','v1c70I83');

        $request = $bdd->prepare("update Guests 
                                        set Team = :teamName
                                        where username = :username;");//passe ce joueur dans une équipe
        $request->bindValue(':teamName',$team->name,PDO::PARAM_STR);
        $request->bindValue(':username',$this->username,PDO::PARAM_STR);
        $request->execute();
        $this->team = $team;

    }

    public function unsetTeam() {
        $bdd = new PDO ("pgsql:host=localhost;dbname=postgres",'postgres','v1c70I83');

        $request = $bdd->prepare("update Guests 
                                        set Team = null
                                        where username = :username;");//retire se joueur son equipe
        $request->bindValue(':username',$this->username,PDO::PARAM_STR);
        $request->execute();
        $this->team->removePlayer($this);
        $this->team = null;//annule l'équipe affilié
    }

    //à modifier
    public function unsetPlayer($bdd){
        //check ouverture insciption, si true utilisation code ci-dessous.
        //check ouverture insciption, si false bloquer l'option.

        $request = $bdd->prepare("update Guests 
                                        set isPlayer = false
                                        where username = :username;");//passe le joueur en tant que membre
        $request->bindParam(':username',$this->username);
        $request->execute();
        if ($this->team != null) {// si le joueur est dans une equipe
            $this->unsetTeam();
        }
        return new Member($this->username, $this->getMail(), $this->getName(), ($this->getFirstname()), $this->getBirthday(), $this->getPassword(), $this->getIsRegistering());
    }

    public function createTeam($teamName,$player,$bdd){
        $requete=$bdd->prepare("INSERT INTO Team VALUES (:teamName,0,0,0)");
        $requete->bindParam(':teamName',$teamName);
        $requete->execute();

        $requete=$bdd->prepare("INSERT INTO Capitain VALUES (:capUsername,:teamName)");
        $requete->bindParam(':capUsername',$this->username);
        $requete->bindParam(':teamName',$teamName);
        $requete->execute();

        $requete=$bdd->prepare("UPDATE Guests SET Team=:teamName WHERE username=:playerUsername");
        $requete->bindParam(':teamName',$teamName);
        $requete->bindParam('playerUsername',$player->username);
        $requete->execute();
    }

    public function scearchName($teamName,$bdd){
        $requete = $bdd->prepare("SELECT * FROM Team WHERE teamName=:teamName");
        $requete->bindParam(':teamName',$teamName);
        $requete->execute();
        $isPresent=$requete->fetchAll();
        if ($isPresent!=null) {
            return True;//renvoie true si il est dans la base de donné
        }else{
            return False;//renvoie false si il n'est pas dans la base de donné
        }
    }
}
