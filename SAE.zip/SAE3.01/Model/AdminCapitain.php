<?php
class AdminCapitain extends PlayerAdministrator {
    public Team $team;
    function __construct($un, $m, $n, $fn, $b, $p, $tn)
    {
        parent::__construct($un, $m, $n, $fn, $b, $p);
        $this->team = new Team($tn);
        $this->team->setCapitain($this);
    }

    function updateTeam($player){//à modifier
        for ($i=0;$player==$this->team->listPlayer[$i];$i++){
            if ($player==$this->team->listPlayer[$i]){
                $this->team->removePlayer($player);
            }

        }
        $this->team->addPlayer($player);

        /* si 1 cap et un joueur et qu on veux suprimmer un joueur alors dissoudre l equipe
         * si 4 joueur bloquer l ajout de joueur
         * dois pouvoir voir la liste de joueur
         * condition si joueur choisi
         *     retirer joueur
         * sinon
         *     ajouter joueur
         */
    }

    public function deleteTeam(){//dissoudre
        $bdd = new PDO ("pgsql:host=localhost;dbname=postgres", 'postgres', 'v1c70I83');

        $request = $bdd->prepare("Delete 
                                        from capitain
                                        WHERE username = :username ");//retire se joueur son equipe
        $request->bindValue(':username', $this->username, PDO::PARAM_STR);
        $teamname = $request->execute();
        $request2 = $bdd->prepare("Delete
                                        From Team
                                        where teamname = :teamname ");
        $request2->bindParam(':teamname', $teamname);
        $request2->execute();
        $requete = $bdd->prepare("UPDATE Guests SET Team=null WHERE username=:capUsername");
        $requete->bindParam(':capUsername', $this->username);
        $requete->execute();
        new Player($this->username, $this->getMail(), $this->getName(), $this->getFirstname(), $this->getBirthday(), $this->getPassword());
    }

    function searchPlayer($search/*recherche nom,prénom ou username,*/): array{
        $players = array();
        $bdd = new PDO ("pgsql:host=localhost;dbname=postgres",'postgres','v1c70I83');
        $lines = array("username", "name", "firstname");
        for ($i=0; $i<3; $i++) {
            $SUN = $bdd->prepare("SELECT username, name, firstname, team 
                                        FROM Guests 
                                        WHERE :lines = :search");//recherche dans la base de donné
            $SUN->bindParam(':lines',$lines[i]);
            $SUN->bindParam(':search',$search);
            $SUN->execute();
            $SUN = $SUN->fetchAll();
            foreach ($SUN as $row) {
                $attributes = array();
                $attributes[0] = $row['username']; // Accède à la colonne 'username'
                $attributes[1] = $row['name'];    // Accède à la colonne 'name'
                $attributes[2] = $row['firstname']; // Accède à la colonne 'firstname'
                $attributes[3] = $row['team'];  // accède à la colonne 'Team'
                $players[-1] = $attributes;
            }
        }
        return $players;
    }

    function addPlayer($seachPlayer){
        $this->team->addPlayer($seachPlayer);
    }

    function bet($match){
        if($match->getTeam1=$this){
            $match->setBetT1($this);
        }
        else{
            $match->setBetT2($this);
        }
    }

    function chooseNewCapitain($playerSelected){
        $bdd = new PDO ("pgsql:host=localhost;dbname=postgres",'postgres','v1c70I83');
        $request = $bdd->prepare("update capitain set username = :playerSelectedUsername where teamname = :teamName");
        $request->execute();

        /* passer le joueur choisi en cap
         * setCap le nouveau cap
         * on passe l ancien cap en joueur. */
    }
}