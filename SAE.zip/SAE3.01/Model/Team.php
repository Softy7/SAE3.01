<?php

require_once('Player.php');
class Team {
    public string $name;
    public array $listPlayer;
    public array $listMatch;

    public function __construct($name)
    {
        $this->listPlayer = array();
        $this->name = $name;
        $this->listMatch = array();
        $bdd = new PDO("pgsql:host=localhost;dbname=postgres", 'postgres', 'v1c70I83');
        $req = $bdd->prepare("select username, mail, name, firstname, birthday, password, isadmin from guests where team = :teamName");
        $req->bindValue(":teamName", $name, PDO::PARAM_STR);
        $req->execute();
        $req = $req->fetchAll();
        $req1 = $bdd->prepare("select username from capitain where teamname = :teamName");
        $req1->bindValue(":teamName", $name, PDO::PARAM_STR);
        $req1->execute();
        $req1 = $req1->fetchAll();
        foreach ($req as $result) {
            if ($req1[0][0] == $req[1] && $req[6] == 1) {
                $this->listPlayer[-1] = new AdminCapitain($req[0], $req[1], $req[2], $req[3], $req[4], $req[5], $this);
            }
            else if ($req[6] == 1) {
                $this->listPlayer[-1] = new PlayerAdministrator($req[0], $req[1], $req[2], $req[3], $req[4], $req[5], $this);
            } else {
                $this->listPlayer[-1] = new Player($req[0], $req[1], $req[2], $req[3], $req[4], $req[5], $this);
            }
        }
    }

    function setCapitain($capi): bool {
        if ($capi == null) {
            return false;
        } else {
            $this->capitain = $capi;
            return true;
        }
    }

    function addPlayer($player): bool {
        if (count($this->listPlayer)>=4) {
            return false;
        } else {
            $this->listPlayer[-1] = $player;
            $player->setTeam($this);
            return true;
        }
    }

    function removePlayer($player): void {
        $list = array();
        for ($i = 0; $i < count($this->listPlayer); $i++) {
            if ($list[$i] != $player) {
                $list[-1] = $this->listPlayer[$i];
            }
        }
        $this->listPlayer = $list;
    }

    function setMatch($match): void {
        $this->listMatch[-1] = $match;
    }


}