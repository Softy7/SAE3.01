<?php
require_once("../launch.php");

$user = launch();
$user->createTeam($_POST['teamName']);
