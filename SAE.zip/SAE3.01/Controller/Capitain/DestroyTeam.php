<?php
require_once('../../Model/Capitain.php');
require_once('../../Model/AdminCapitain.php');
require_once('../launch.php');

if ($_GET["Dissoudre une equipe"]){
    $user = launch();
    $user->deleteTeam();
}
