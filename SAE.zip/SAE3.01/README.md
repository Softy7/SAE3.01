# SAE3.01
Bonjour, vous êtes ici sur le projet de la création d'un site web pour gérer un tournoi
de chôlage. Ce projet est réalisé par l'Informa-Team dans le cadre de la SAE 3.01 du BUT 
Informatique. Si vous n'avez rien à voir avec cette SAE, je vous prierai de ne pas toucher
à quoi que ce soit et quitter la page. Merci.

- Chef de projet: Michel Ewan
- Sous-Chef de projet: Meriaux Thomas  
Accompagnés de:
- Monsieur Benredouane Iliès
- Monsieur Hostelart Anthony
- Monsieur Faës Hugo


 
