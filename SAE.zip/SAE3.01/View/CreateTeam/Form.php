<?php
session_start();
$bdd = new PDO("pgsql:host=localhost;dbname=postgres",'postgres','v1c70I83');
$requete = $bdd->prepare("SELECT * FROM Guests WHERE Team is null /*and username != :username*/");
/*$requete->bindValue(':username', $_SESSION['username'],PDO::PARAM_STR );*/
$requete->execute();
$donnees = $requete->fetchAll();

?>
<!DOCTYPE html>
<html lang="FR">

<head>
    <meta charset="utf-8">
    <title>Formulaire creation d'équipe</title>
    <link href="form.css" rel="stylesheet">
</head>
<body>
<main>
    <header>
    </header>

    <form action="" method="post">
        <h1>Entrer votre nom d'équipe</h1>
        <div class="page" id="page1">
            <div>
                <label>Nom d'équipe:</label>
                <input type="text" name="teamName">
            </div>
            <button type="button">Suivant</button>
            <button type="button">Retour</button>

        </div>

    </form>
</main>

</form>
<script src="form.js"></script>
</body>
</html>