<?php
session_start();

if ($_SESSION['connected']) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>ChomeurCholeur.fr</title>
    </head>
    <body>
    <p>Bienvenue sur votre espace Membre ! Monsieur <?php echo $_SESSION['username']?></p>
    //à faire disparaitre quand les inscription sont fermées
    <?php
    if ($_SESSION['openn'] == 1) {
        if ($_SESSION['capitain'] == 1) {
            ?>
        }
            <form action='../../Controller/Capitain/DestroyTeam.php'
                <button id="searchPlayer" value="recruter un joueur"></button>
                <button id="changeCapitain" value="recruter un joueur"></button>
                <button id="destroyTeam" value="Dissoudre une equipe">Dissoudre une equipe</button>
            </form>
            <?php
        }
        ?>
        }
        if ($_SESSION['isPlayer'] != 1) {
            echo "<form action='../Registering/registeringTournament.php' method='post'>
            <input type='submit' value='Inscription Tournoi'/>
            </form>";
        } else {
            echo "<form action='../Unregistering/unregisteringTournament.php' method='post'>
            <input type='submit' value='Désinscription Tournoi'/>
            </form>";
        }
    }
    ?>s
    <form action="../Unregistering/unregisteringWebsite.php" method="post">
        <input type="submit" value="Supprimer le compte"/>
    </form>
    <p><?php echo $_SESSION['open'];?></p>
    <form action="../../Controller/Connect/Deconnect.php" method="post">
        <input type="submit" value="Déconnexion" />
    </form>
    </body>
    </html>
    <?php
} else {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>ChomeurCholeur.fr</title>
    </head>
    <body>
    <h1>404 not found</h1>

    </body>
    </html>
    <?php
}
}