<?php
session_start();

if ($_SESSION['isAdmin'] == 1 && $_SESSION['isPlayer'] == 1 && $_SESSION['capitain'] == 1) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>ChomeurCholeur.fr</title>
    </head>
    <body>
    <p>Bienvenue sur votre espace Capitaine Administrateur ! Monsieur <?php echo $_SESSION['username']?></p>
    //à faire disparaitre quand les inscription sont fermées
    <?php
    if ($_SESSION['openn'] == 1){?>
        <form action='../Unregistering/unregisteringTournament.php' method='post'>
            <input type='submit' value='Désinscription Tournoi'/>
        </form>
        <?php
    }

    if ($_SESSION['openn'] == 1){ ?>
        <form action='../../Capitain/DestroyTeam.php'
        <button id="dissoudreEquipe" value="Dissoudre une equipe">Dissoudre une equipe</button>
        <button id="chercherJoueur" value="recruter un joueur">Recruter un joueur</button>
        <?php
    }
    ?>
    </form>
    }

    //mets les bouton en dessous de cette balise?>
    <form action='../AdminViews/ViewInRegistering.php' method='post'>
        <input type='submit' value='Voir Demande inscription'/>
    </form>
    //à faire disparaitre condition seul admin
    <?php
    if ($_SESSION['lenght'] > 1){
        echo "<form method='post'>
    <input type='submit' value='Supprimer le compte'/>
    </form>";
    }else{
        echo "<p>vous ne pouvez pas vous désincrire car vous êtes le seul administrateur du site</p>";
    }
    ?>
    <p><?php echo $_SESSION['open'];?></p>
    //à ajouter le nombre inscrit au tournois.
    <?php
    if ($_SESSION['openn'] == 1) {
        echo "<form action='../../Controller/Registering/RegisterOpen.php' method='post'>
            <input type='submit' value='Fermer Inscriptions' />
            </form>";
    } else {
        echo "<form action='../../Controller/Registering/RegisterOpen.php' method='post'>
        <input type='submit' value='Ouvrir Inscriptions' />
        </form>";
    }
    //ajouter fonction pour voir le nombre d'inscrit au tournois
    ?>
    <form action="../../Controller/AdminFunctions/UnregisteredViewInit.php" method="post">
        <input type="submit" value="Voir désinscrits" />
    </form>
    <form action="../../Controller/Connect/Deconnect.php" method="post">
        <input type="submit" value="Déconnexion" />
    </form>
    <form action='../../Model/AdminCapitain.php'>
        <button>id="creerEquipe"; value="Créer une equipe"</button>
        <button>id="dissoudreEquipe"</button>
    </form>;


    <form action="../Unregistering/unregisteringWebsite.php" method="post">
        <input type="submit" value="Supprimer le compte"/>
    </form>
    <p><?php echo $_SESSION['open'];?></p>
    <form action="../../Controller/Connect/Deconnect.php" method="post">
        <input type="submit" value="Déconnexion" />
    </form>
    </body>
    </html>
    <?php
} else {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>ChomeurCholeur.fr</title>
    </head>
    <body>
    <h1>404 not found</h1>

    </body>
    </html>
    <?php
}
