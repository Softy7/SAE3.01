<?php
session_start();

if ($_SESSION['isAdmin'] != 1 && $_SESSION['isPlayer'] == 1) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ChomeurCholeur.fr</title>
</head>
<body>
<p>Bienvenue sur votre espace Joueur ! Monsieur <?php echo $_SESSION['username']?></p>
//à faire disparaitre quand les inscription sont fermées
<?php
if ($_SESSION['openn'] == 1) {
    echo "<form action='../Unregistering/unregisteringTournament.php' method='post'>
            <input type='submit' value='Désinscription Tournoi'/>
            </form>";
}
?>
<form action="../Unregistering/unregisteringWebsite.php" method="post">
    <input type="submit" value="Supprimer le compte"/>
</form>
<p><?php echo $_SESSION['open'];?></p>
<form action="../../Controller/Connect/Deconnect.php" method="post">
    <input type="submit" value="Deconnexion" />
</form>
<button onclick="window.location.href='../CreateTeam/Form.php';" id="creerEquipe" value="Créer Equipe"> Créer une équipe </button>
</body>
</html>
<?php
} else {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>ChomeurCholeur.fr</title>
    </head>
    <body>
    <h1>404 not found</h1>

    </body>
    </html>
<?php
}