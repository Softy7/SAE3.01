<?php
session_start();

if ($_SESSION['isAdmin'] == 1 && $_SESSION['isPlayer'] != 1) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cholage Club Quaroule.fr</title>
</head>
<body>
<p>Bienvenue sur votre espace Administrateur ! Monsieur l'Administrateur <?php echo $_SESSION['username']?></p>
<?php
if ($_SESSION['openn'] == 1) {
    echo "<form action='../Registering/registeringTournament.php' method='post'>
    <input type='submit' value='Inscription Tournoi'/>
    </form>";
}
?>
<form action='../AdminViews/ViewInRegistering.php' method='post'>
    <input type='submit' value='Voir Demande inscription'/>
</form>
<?php
if ($_SESSION['lenght'] > 1){
    echo "<form method='post'>
    <input type='submit' value='Supprimer le compte'/>
    </form>";
}else{
    echo "<p>vous ne pouvez pas vous désincrire car vous êtes le seul administrateur du site</p>";
}
?>
<p><?php echo $_SESSION['open'];?></p>
//à ajouter le nombre inscrit au tournois.
<?php
if ($_SESSION['openn'] == 1) {
    echo "<form action='../../Controller/Registering/RegisterOpen.php' method='post'>
            <input type='submit' value='Fermer Inscriptions' />
            </form>";
} else {
    echo "<form action='../../Controller/Registering/RegisterOpen.php' method='post'>
        <input type='submit' value='Ouvrir Inscriptions' />
        </form>";
}
//ajouter fonction pour voir le nombre d'inscrit au tournois
?>
<form action="../../Controller/AdminFunctions/UnregisteredViewInit.php" method="post">
    <input type="submit" value="Voir désinscrits" />
</form>
<form action="../../Controller/Connect/Deconnect.php" method="post">
    <input type="submit" value="Déconnexion" />
</form>
</body>
</html>
<?php
} else {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Cholage Club Quaroule.fr</title>
    </head>
    <body>
    <h1>404 not found</h1>

    </body>
    </html>
<?php
}
