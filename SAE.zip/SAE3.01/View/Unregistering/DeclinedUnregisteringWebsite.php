<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UFT-8">
    <title>Désinscription</title>
</head>
<body>
<h1>Fin désinscription.</h1>
<p>Désinscription non effectuée. Les inscriptions sont fermées.</p>
<form action= "../../Controller/Connect/CheckConnect.php" method="post">
    <input type="submit" value="Retourner sur la page principale" name="" id="2"/>
</form>
</body>
</html>