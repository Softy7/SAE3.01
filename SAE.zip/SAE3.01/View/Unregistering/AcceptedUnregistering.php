<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UFT-8">
    <title>Désinscription</title>
</head>
<body>
<h1>Désinscription du tournois finalisée.</h1>
<p>Désinscription réussie. Vous pouvez retourner sur votre espace Membre.</p>
<form action= "../../Controller/Connect/CheckConnect.php" method="post">
    <input type="submit" value="Retourner sur la page principale" name="" id="2"/>
</form>
</body>
</html>