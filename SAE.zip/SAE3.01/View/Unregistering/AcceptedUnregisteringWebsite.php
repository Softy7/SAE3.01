<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UFT-8">
    <title>Désinscription</title>
</head>
<body>
<h1>Fin désinscription</h1>
<p>Désinscription effectuée, veuillez fermer le site.</p>
</body>
</html>