<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Quarouble Cholage Club.fr</title>
</head>
<body>
<h3>Votre inscription a été refutee, le mot de passe rentré ne correspond pas à votre confirmation !</h3>
<button onclick="window.location.href ='../Guest_Home.html';">Accueil</button>
</body>
</html>