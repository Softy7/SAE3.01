<?php
$bdd = new PDO ("pgsql:host=localhost;dbname=postgres",'postgres','v1c70I83');
$username = "Softy16";
$req = $bdd->prepare("UPDATE Guests set isRegistered = true WHERE username = '$username'");
$req->execute();
$reqMail = $bdd->prepare("SELECT mail FROM guests WHERE username = '$username'");
$reqMail->execute();
$mail = $reqMail->fetchAll()[0][0];
$to = "$mail";
$subject = "Réponse demande d'inscription cholage";
$message = "Votre demande a été accepté";

// Pour envoyer un e-mail HTML, vous pouvez définir le type de contenu de l'en-tête
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Vous pouvez également définir l'expéditeur de l'e-mail
$headers .= 'From: meriauxthomasjeanherve@gmail.com' . "\r\n";

// Envoi de l'e-mail
$mailSent = mail($to, $subject, $message, $headers);